//! pse_net — command-line interface.
//!
//!   pse_net encode  <file>
//!   pse_net decode  <number> [<number> ...]
//!   pse_net receive --port 5050 --out-dir recv [--max-clients 16] [--max-frame-mb 64] [--once]
//!                   [--tls-cert cert.pem --tls-key key.pem]
//!   pse_net send    --host 127.0.0.1 --port 5050 <file> [--mode bcd|raw] [--chunk-kb 1024]
//!                   [--tls-ca ca.pem --server-name localhost]
use pse_net::{codec, frame::Mode, net};
use std::path::PathBuf;
use std::process::ExitCode;

fn usage() -> ExitCode {
    eprintln!("usage:\n  pse_net encode <file>\n  pse_net decode <number>...\n  \
pse_net receive --port P --out-dir DIR [--max-clients N] [--max-frame-mb N] [--once] [--tls-cert C --tls-key K]\n  \
pse_net send --host H --port P <file> [--mode bcd|raw] [--chunk-kb N] [--tls-ca CA --server-name NAME]");
    ExitCode::from(2)
}

struct Args {
    pos: Vec<String>,
    kv: Vec<(String, String)>,
    flags: Vec<String>,
}

const OPTIONS: &[&str] = &[
    "port",
    "host",
    "out-dir",
    "max-clients",
    "max-frame-mb",
    "tls-cert",
    "tls-key",
    "tls-ca",
    "server-name",
    "mode",
    "chunk-kb",
];

/// Strict parser: unknown or value-less options are errors (a mistyped --tls-ca must not
/// silently fall back to an unencrypted connection).
fn parse(a: &[String]) -> Result<Args, String> {
    let (mut pos, mut kv, mut flags) = (vec![], vec![], vec![]);
    let mut i = 0;
    while i < a.len() {
        if let Some(k) = a[i].strip_prefix("--") {
            if k == "once" {
                flags.push(k.to_string());
            } else if OPTIONS.contains(&k) {
                let v = a
                    .get(i + 1)
                    .filter(|v| !v.starts_with("--"))
                    .ok_or(format!("--{k} needs a value"))?;
                kv.push((k.to_string(), v.clone()));
                i += 1;
            } else {
                return Err(format!("unknown option --{k}"));
            }
        } else {
            pos.push(a[i].clone());
        }
        i += 1;
    }
    Ok(Args { pos, kv, flags })
}

impl Args {
    fn get(&self, k: &str) -> Option<&str> {
        self.kv
            .iter()
            .find(|(a, _)| a == k)
            .map(|(_, v)| v.as_str())
    }
    fn num(&self, k: &str, d: usize) -> Result<usize, String> {
        self.get(k)
            .map(|v| {
                v.parse::<usize>()
                    .map_err(|_| format!("--{k} must be a number"))
            })
            .unwrap_or(Ok(d))
    }
    fn port(&self) -> Result<u16, String> {
        let p = self.num("port", 5050)?;
        u16::try_from(p)
            .ok()
            .filter(|&p| p != 0)
            .ok_or(format!("--port must be 1..65535, got {p}"))
    }
}

fn run(cmd: &str, a: Args) -> Result<(), String> {
    match cmd {
        "encode" => {
            let data =
                std::fs::read(a.pos.first().ok_or("missing file")?).map_err(|e| e.to_string())?;
            for c in data.chunks(4) {
                let mut b = [0u8; 4];
                b[..c.len()].copy_from_slice(c);
                println!("{}", codec::encode_block(b));
            }
            if data.len() % 4 != 0 {
                eprintln!(
                    "# last block padded with {} zero byte(s)",
                    4 - data.len() % 4
                );
            }
        }
        "decode" => {
            let mut out = String::new();
            for n in &a.pos {
                for b in codec::decode_block(n).map_err(|e| e.to_string())? {
                    out.push_str(&format!("{b:02x}"));
                }
            }
            println!("{out}");
        }
        "receive" => {
            let tls = match (a.get("tls-cert"), a.get("tls-key")) {
                (Some(c), Some(k)) => Some(
                    net::tls_server_config(c.as_ref(), k.as_ref())
                        .map_err(|e| format!("TLS: {e}"))?,
                ),
                (None, None) => None,
                _ => return Err("--tls-cert and --tls-key must be given together".into()),
            };
            net::serve(net::ServerOptions {
                port: a.port()?,
                out_dir: PathBuf::from(a.get("out-dir").unwrap_or("received")),
                max_clients: a.num("max-clients", 16)?.max(1),
                max_frame: a.num("max-frame-mb", 64)?.clamp(1, 2048) << 20,
                once: a.flags.iter().any(|f| f == "once"),
                tls,
            })
            .map_err(|e| e.to_string())?;
        }
        "send" => {
            let file = PathBuf::from(a.pos.first().ok_or("missing file")?);
            let mode = match a.get("mode").unwrap_or("bcd") {
                "bcd" => Mode::Bcd,
                "raw" => Mode::Raw,
                m => return Err(format!("unknown mode {m}")),
            };
            let tls = match a.get("tls-ca") {
                Some(ca) => Some((
                    net::tls_client_config(ca.as_ref()).map_err(|e| format!("TLS: {e}"))?,
                    a.get("server-name").unwrap_or("localhost").to_string(),
                )),
                None => None,
            };
            let host = a.get("host").unwrap_or("127.0.0.1");
            let chunk_kb = a.num("chunk-kb", 1024)?;
            if !(1..=65536).contains(&chunk_kb) {
                return Err("--chunk-kb must be 1..65536".into());
            }
            let mut s = net::connect(host, a.port()?, tls).map_err(|e| e.to_string())?;
            let opt = net::SendOptions {
                mode,
                chunk: chunk_kb << 10,
                retries: 3,
            };
            let r = net::send_file(s.as_mut(), &file, &opt).map_err(|e| e.to_string())?;
            println!("sent {} bytes in {} frame(s) as {} bytes on the wire ({:?}{}), retries {} -> verified",
                     r.data_bytes, r.frames, r.wire_bytes, mode, if a.get("tls-ca").is_some() { ", TLS" } else { "" }, r.retries);
        }
        _ => return Err("unknown command".into()),
    }
    Ok(())
}

fn main() -> ExitCode {
    let argv: Vec<String> = std::env::args().skip(1).collect();
    let Some(cmd) = argv.first().cloned() else {
        return usage();
    };
    if !["encode", "decode", "receive", "send"].contains(&cmd.as_str()) {
        return usage();
    }
    let args = match parse(&argv[1..]) {
        Ok(a) => a,
        Err(e) => {
            eprintln!("error: {e}");
            return ExitCode::from(2);
        }
    };
    match run(&cmd, args) {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: {e}");
            ExitCode::FAILURE
        }
    }
}
