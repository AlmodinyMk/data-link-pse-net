//! PSE2 frame (big-endian, wire-compatible with pse_net_plain.py):
//!
//! | magic "PSE2" (4) | mode (1) | flags (1) | original length (4) | body length (4) | CRC-32 (4) | body |
//!
//! mode : 1 = bcd (system digits, 6 bytes per 4 data bytes), 2 = raw (data as is)
//! flags: bit0 = encrypted (refused: use TLS), bit1 = STREAM (more frames follow on this
//!        connection), bit2 = LAST (final frame of a stream). Python peers use flags = 0.

use crate::codec::{self, CodecError};

pub const MAGIC: &[u8; 4] = b"PSE2";
pub const HDR_LEN: usize = 18;
pub const MODE_BCD: u8 = 1;
pub const MODE_RAW: u8 = 2;
pub const FLAG_ENC: u8 = 0x01;
pub const FLAG_STREAM: u8 = 0x02;
pub const FLAG_LAST: u8 = 0x04;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Mode {
    Bcd,
    Raw,
}

#[derive(Debug)]
pub enum FrameError {
    TooShort,
    BadMagic,
    Truncated,
    Encrypted,
    UnknownMode(u8),
    Crc,
    Codec(CodecError),
}

impl std::fmt::Display for FrameError {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        match self {
            FrameError::TooShort => write!(f, "frame too short"),
            FrameError::BadMagic => write!(f, "not a PSE frame"),
            FrameError::Truncated => write!(f, "truncated frame"),
            FrameError::Encrypted => {
                write!(f, "encrypted frame refused (use TLS transport instead)")
            }
            FrameError::UnknownMode(m) => write!(f, "unknown mode {m}"),
            FrameError::Crc => write!(f, "CRC-32 mismatch: data corrupted in transit"),
            FrameError::Codec(e) => write!(f, "{e}"),
        }
    }
}
impl std::error::Error for FrameError {}
impl From<CodecError> for FrameError {
    fn from(e: CodecError) -> Self {
        FrameError::Codec(e)
    }
}

/// CRC-32 (IEEE 802.3, reflected, same as zlib.crc32).
pub fn crc32(data: &[u8]) -> u32 {
    static TABLE: std::sync::OnceLock<[u32; 256]> = std::sync::OnceLock::new();
    let t = TABLE.get_or_init(|| {
        let mut t = [0u32; 256];
        for (i, e) in t.iter_mut().enumerate() {
            let mut c = i as u32;
            for _ in 0..8 {
                c = if c & 1 != 0 {
                    0xEDB8_8320 ^ (c >> 1)
                } else {
                    c >> 1
                };
            }
            *e = c;
        }
        t
    });
    let mut c = 0xFFFF_FFFFu32;
    for &b in data {
        c = t[((c ^ b as u32) & 0xFF) as usize] ^ (c >> 8);
    }
    c ^ 0xFFFF_FFFF
}

pub fn make_frame(data: &[u8], mode: Mode, flags: u8) -> Vec<u8> {
    let (m, body) = match mode {
        Mode::Raw => (MODE_RAW, data.to_vec()),
        Mode::Bcd => (MODE_BCD, codec::bcd_pack(&codec::bytes_to_digits(data))),
    };
    let mut f = Vec::with_capacity(HDR_LEN + body.len());
    f.extend_from_slice(MAGIC);
    f.push(m);
    f.push(flags);
    f.extend_from_slice(&(data.len() as u32).to_be_bytes());
    f.extend_from_slice(&(body.len() as u32).to_be_bytes());
    f.extend_from_slice(&crc32(data).to_be_bytes());
    f.extend_from_slice(&body);
    f
}

pub struct Parsed {
    pub data: Vec<u8>,
    pub flags: u8,
    pub mode: Mode,
}

pub fn parse_frame(f: &[u8]) -> Result<Parsed, FrameError> {
    if f.len() < HDR_LEN {
        return Err(FrameError::TooShort);
    }
    if &f[0..4] != MAGIC {
        return Err(FrameError::BadMagic);
    }
    let (m, flags) = (f[4], f[5]);
    let n = u32::from_be_bytes(f[6..10].try_into().unwrap()) as usize;
    let blen = u32::from_be_bytes(f[10..14].try_into().unwrap()) as usize;
    let crc = u32::from_be_bytes(f[14..18].try_into().unwrap());
    // the frame must contain exactly the header and the declared body
    if f.len() != HDR_LEN + blen {
        return Err(FrameError::Truncated);
    }
    let body = &f[HDR_LEN..];
    if flags & FLAG_ENC != 0 {
        return Err(FrameError::Encrypted);
    }
    let (data, mode) = match m {
        MODE_RAW => {
            if blen != n {
                return Err(FrameError::Truncated);
            }
            (body.to_vec(), Mode::Raw)
        }
        MODE_BCD => {
            // validate the declared length against the body BEFORE allocating anything from it
            if blen as u64 != (n as u64).div_ceil(4) * 6 {
                return Err(FrameError::Truncated);
            }
            let ndig = n.div_ceil(4) * 12;
            let digits = codec::bcd_unpack(body, ndig)?;
            (codec::digits_to_bytes(&digits, n)?, Mode::Bcd)
        }
        other => return Err(FrameError::UnknownMode(other)),
    };
    if crc32(&data) != crc {
        return Err(FrameError::Crc);
    }
    Ok(Parsed { data, flags, mode })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn crc_matches_zlib() {
        assert_eq!(crc32(b"123456789"), 0xCBF4_3926); // standard check value
    }

    #[test]
    fn round_trips_and_padding() {
        for n in [0usize, 1, 3, 4, 5, 1000] {
            let d: Vec<u8> = (0..n).map(|i| (i * 37 % 256) as u8).collect();
            for mode in [Mode::Bcd, Mode::Raw] {
                assert_eq!(parse_frame(&make_frame(&d, mode, 0)).unwrap().data, d);
            }
        }
    }

    #[test]
    fn every_single_bit_flip_is_detected() {
        let d: Vec<u8> = (0..64u32).map(|i| (i * 91 % 256) as u8).collect();
        for mode in [Mode::Bcd, Mode::Raw] {
            let f = make_frame(&d, mode, 0);
            for byte in HDR_LEN..f.len() {
                for bit in 0..8 {
                    let mut g = f.clone();
                    g[byte] ^= 1 << bit;
                    assert!(parse_frame(&g).is_err(), "undetected flip at {byte}:{bit}");
                }
            }
        }
    }

    #[test]
    fn hostile_length_fields_rejected_without_allocation() {
        // declared original length 4 GiB with a 6-byte body: must be rejected, not allocated
        let mut f = make_frame(&[1, 2, 3, 4], Mode::Bcd, 0);
        f[6..10].copy_from_slice(&u32::MAX.to_be_bytes());
        assert!(matches!(parse_frame(&f), Err(FrameError::Truncated)));
        // trailing bytes after the declared body
        let mut g = make_frame(&[1, 2, 3, 4], Mode::Raw, 0);
        g.push(0);
        assert!(matches!(parse_frame(&g), Err(FrameError::Truncated)));
        // body length larger than the frame
        let mut h = make_frame(&[1, 2, 3, 4], Mode::Raw, 0);
        h[10..14].copy_from_slice(&1000u32.to_be_bytes());
        assert!(matches!(parse_frame(&h), Err(FrameError::Truncated)));
    }

    #[test]
    fn swapped_bytes_detected() {
        let mut f = make_frame(&[1, 2, 3, 4], Mode::Raw, 0);
        let l = f.len();
        f.swap(l - 4, l - 3);
        assert!(parse_frame(&f).is_err());
    }

    #[test]
    fn malformed_rejected() {
        assert!(matches!(parse_frame(b"PSE2"), Err(FrameError::TooShort)));
        assert!(matches!(parse_frame(&[0u8; 18]), Err(FrameError::BadMagic)));
        let mut f = make_frame(&[1, 2, 3, 4], Mode::Raw, 0);
        f[5] = FLAG_ENC;
        assert!(matches!(parse_frame(&f), Err(FrameError::Encrypted)));
    }
}
