//! Weighted Pair-Symbol Encoding (PSE): codec, framing and network transport.
pub mod codec;
pub mod frame;
pub mod net;
