//! Weighted pair-symbol codec.
//!
//! byte -> two 4-bit groups -> four 2-bit pairs (weights 00:2 01:3 10:5 11:13)
//! value X.0YY in units of 0.001 (X = relational state 0..9, YY = sum, ladder for repeats)
//! 4 bytes -> "X4X3X2X1.0YY0YY0YY0YY" -> 12 transmitted digits (fixed zeros dropped)

use std::sync::OnceLock;

/// R2: pair weights indexed by the 2-bit value.
pub const WEIGHTS: [u16; 4] = [2, 3, 5, 13];

#[inline]
fn pair_hi(g: u8) -> u8 {
    (g >> 2) & 0b11
}
#[inline]
fn pair_lo(g: u8) -> u8 {
    g & 0b11
}

/// R4: sum of a 4-bit group.
pub fn group_sum(g: u8) -> u16 {
    WEIGHTS[pair_hi(g) as usize] + WEIGHTS[pair_lo(g) as usize]
}

/// R3: true if the group starts larger (equal counts as "starts smaller").
pub fn starts_larger(g: u8) -> bool {
    WEIGHTS[pair_hi(g) as usize] > WEIGHTS[pair_lo(g) as usize]
}

/// R5: smaller sum is smaller; on equal sums the group that starts larger is larger.
pub fn first_is_smaller(g1: u8, g2: u8) -> bool {
    let (s1, s2) = (group_sum(g1), group_sum(g2));
    if s1 != s2 {
        s1 < s2
    } else {
        !starts_larger(g1) && starts_larger(g2)
    }
}

/// R6: the ten relational states (1..=10).
pub fn state(g1: u8, g2: u8) -> u8 {
    let (f1, f2) = (starts_larger(g1), starts_larger(g2));
    if g1 == g2 {
        return if f1 { 9 } else { 10 };
    }
    let base = match (f1, f2) {
        (false, false) => 1,
        (true, false) => 3,
        (false, true) => 5,
        (true, true) => 7,
    };
    if first_is_smaller(g1, g2) {
        base
    } else {
        base + 1
    }
}

/// State number -> integer digit X (state 10 -> 0).
pub fn state_value(st: u8) -> u16 {
    if st == 10 {
        0
    } else {
        st as u16
    }
}

pub struct Table {
    /// byte -> value in units of 0.001
    pub enc: [u16; 256],
    /// value (0..9999) -> byte, or -1
    pub dec: Vec<i16>,
}

fn build() -> Table {
    // per state: list of (sum, smaller-group sum, byte)
    let mut by_state: Vec<Vec<(u16, u16, u8)>> = vec![Vec::new(); 10];
    for b in 0u16..256 {
        let (g1, g2) = ((b >> 4) as u8, (b & 0xF) as u8);
        let x = state_value(state(g1, g2)) as usize;
        let s = group_sum(g1) + group_sum(g2);
        by_state[x].push((s, group_sum(g1).min(group_sum(g2)), b as u8));
    }
    let mut enc = [0u16; 256];
    for (x, cells) in by_state.iter_mut().enumerate() {
        cells.sort(); // by sum, then smaller-group sum
        let mut used: Vec<u16> = cells.iter().map(|c| c.0).collect();
        used.dedup();
        let mut next = *used.iter().max().unwrap_or(&0);
        let mut prev_sum: Option<u16> = None;
        for &(s, _, b) in cells.iter() {
            let yy = if prev_sum != Some(s) {
                prev_sum = Some(s);
                s // first cell keeps the sum
            } else {
                next += 1; // ladder: next free step above the state's max
                while used.contains(&next) {
                    next += 1;
                }
                used.push(next);
                next
            };
            enc[b as usize] = x as u16 * 1000 + yy;
        }
    }
    let mut dec = vec![-1i16; 10000];
    for (b, &v) in enc.iter().enumerate() {
        assert!(dec[v as usize] == -1, "table is not one-to-one");
        assert!(v % 1000 < 100, "section would need its first digit");
        dec[v as usize] = b as i16;
    }
    Table { enc, dec }
}

pub fn table() -> &'static Table {
    static T: OnceLock<Table> = OnceLock::new();
    T.get_or_init(build)
}

#[derive(Debug, PartialEq, Eq)]
pub enum CodecError {
    BadNumber(String),
    NotInTable(u16),
    BadDigit,
}

impl std::fmt::Display for CodecError {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        match self {
            CodecError::BadNumber(s) => write!(f, "bad number: {s}"),
            CodecError::NotInTable(v) => write!(
                f,
                "{}.{:03} is not a value of this system",
                v / 1000,
                v % 1000
            ),
            CodecError::BadDigit => write!(f, "invalid BCD digit"),
        }
    }
}
impl std::error::Error for CodecError {}

/// 4 bytes -> "X4X3X2X1.0YY0YY0YY0YY"
pub fn encode_block(b: [u8; 4]) -> String {
    let t = table();
    let v: Vec<u16> = b.iter().map(|&x| t.enc[x as usize]).collect();
    let mut s = String::with_capacity(17);
    for x in v.iter().rev() {
        s.push(char::from(b'0' + (x / 1000) as u8));
    }
    s.push('.');
    for x in &v {
        s.push_str(&format!("{:03}", x % 1000));
    }
    s
}

pub fn decode_block(num: &str) -> Result<[u8; 4], CodecError> {
    let (ip, fp) = num
        .trim()
        .split_once('.')
        .ok_or_else(|| CodecError::BadNumber(num.into()))?;
    if ip.len() != 4 || fp.len() != 12 || !ip.bytes().chain(fp.bytes()).all(|c| c.is_ascii_digit())
    {
        return Err(CodecError::BadNumber(num.into()));
    }
    let (ib, fb) = (ip.as_bytes(), fp.as_bytes());
    let mut out = [0u8; 4];
    for i in 0..4 {
        let x = (ib[3 - i] - b'0') as u16;
        let yyy = (fb[3 * i] - b'0') as u16 * 100
            + (fb[3 * i + 1] - b'0') as u16 * 10
            + (fb[3 * i + 2] - b'0') as u16;
        out[i] = lookup(x * 1000 + yyy)?;
    }
    Ok(out)
}

fn lookup(v: u16) -> Result<u8, CodecError> {
    match table().dec.get(v as usize) {
        Some(&b) if b >= 0 => Ok(b as u8),
        _ => Err(CodecError::NotInTable(v)),
    }
}

/// Bytes -> transmitted digits (0..9 each), 12 per 4-byte block; the last block is zero-padded.
pub fn bytes_to_digits(data: &[u8]) -> Vec<u8> {
    let t = table();
    let mut d = Vec::with_capacity(data.len().div_ceil(4) * 12);
    for chunk in data.chunks(4) {
        let mut b = [0u8; 4];
        b[..chunk.len()].copy_from_slice(chunk);
        let v = [
            t.enc[b[0] as usize],
            t.enc[b[1] as usize],
            t.enc[b[2] as usize],
            t.enc[b[3] as usize],
        ];
        for x in v.iter().rev() {
            d.push((x / 1000) as u8);
        } // X4 X3 X2 X1
        for x in &v {
            let yy = x % 1000;
            d.push((yy / 10) as u8);
            d.push((yy % 10) as u8);
        }
    }
    d
}

/// Transmitted digits -> bytes (n = original length, used to drop padding).
pub fn digits_to_bytes(d: &[u8], n: usize) -> Result<Vec<u8>, CodecError> {
    if d.len() % 12 != 0 {
        return Err(CodecError::BadDigit);
    }
    let mut out = Vec::with_capacity(d.len() / 3);
    for blk in d.chunks(12) {
        for i in 0..4 {
            let x = blk[3 - i] as u16;
            let yy = blk[4 + 2 * i] as u16 * 10 + blk[5 + 2 * i] as u16;
            out.push(lookup(x * 1000 + yy)?);
        }
    }
    out.truncate(n);
    Ok(out)
}

/// Two digits per byte, high nibble first; an odd count is padded with 0xF.
pub fn bcd_pack(d: &[u8]) -> Vec<u8> {
    d.chunks(2)
        .map(|p| (p[0] << 4) | if p.len() == 2 { p[1] } else { 0xF })
        .collect()
}

pub fn bcd_unpack(b: &[u8], ndigits: usize) -> Result<Vec<u8>, CodecError> {
    let mut d = Vec::with_capacity(ndigits);
    for &x in b {
        d.push(x >> 4);
        d.push(x & 0xF);
    }
    d.truncate(ndigits);
    if d.len() != ndigits || d.iter().any(|&v| v > 9) {
        return Err(CodecError::BadDigit);
    }
    Ok(d)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn table_is_bijective_and_sections_start_with_zero() {
        let t = table();
        let mut v: Vec<u16> = t.enc.to_vec();
        v.sort();
        v.dedup();
        assert_eq!(v.len(), 256);
        assert!(t.enc.iter().all(|x| x % 1000 < 100));
        assert_eq!(*t.enc.iter().max().unwrap(), 9036);
    }

    #[test]
    fn paper_example() {
        let n = encode_block([0xE8, 0xF8, 0xEB, 0x9A]);
        assert_eq!(n, "3468.025033036018");
        assert_eq!(decode_block(&n).unwrap(), [0xE8, 0xF8, 0xEB, 0x9A]);
        let d: String = bytes_to_digits(&[0xE8, 0xF8, 0xEB, 0x9A])
            .iter()
            .map(|x| char::from(b'0' + x))
            .collect();
        assert_eq!(d, "346825333618");
    }

    #[test]
    fn exhaustive_two_byte_round_trip() {
        for a in 0..=255u8 {
            for b in 0..=255u8 {
                let d = bytes_to_digits(&[a, b]);
                let p = bcd_pack(&d);
                let back = digits_to_bytes(&bcd_unpack(&p, d.len()).unwrap(), 2).unwrap();
                assert_eq!(back, vec![a, b]);
            }
        }
    }
}
