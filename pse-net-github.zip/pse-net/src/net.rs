//! Transport layer.
//!
//! Reliability, ordering, retransmission, congestion control and segmentation are provided by
//! TCP and are deliberately not re-implemented here. This layer adds:
//!   * framing with a 4-byte length prefix and a per-frame acknowledgement ("OK" / "ER" / "BY")
//!   * application-level retry of a frame that fails verification (bounded)
//!   * chunked streaming of large files (constant memory) with an atomic write on completion
//!   * a concurrent server with a connection limit, timeouts and size limits
//!   * optional TLS 1.2/1.3 (rustls) for confidentiality, integrity and server authentication

use crate::frame::{self, Mode, FLAG_LAST, FLAG_STREAM};
use std::fs::{self, File};
use std::io::{self, BufReader, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

pub const ACK_OK: &[u8; 2] = b"OK";
pub const ACK_ERR: &[u8; 2] = b"ER";
pub const ACK_BUSY: &[u8; 2] = b"BY";

pub trait Stream: Read + Write + Send {}
impl<T: Read + Write + Send> Stream for T {}

fn other<E: std::fmt::Display>(e: E) -> io::Error {
    io::Error::other(e.to_string())
}

// ------------------------------------------------------------------ TLS setup
fn load_certs(path: &Path) -> io::Result<Vec<rustls::pki_types::CertificateDer<'static>>> {
    rustls_pemfile::certs(&mut BufReader::new(File::open(path)?)).collect()
}

pub fn tls_server_config(cert: &Path, key: &Path) -> io::Result<Arc<rustls::ServerConfig>> {
    let certs = load_certs(cert)?;
    let key = rustls_pemfile::private_key(&mut BufReader::new(File::open(key)?))?
        .ok_or_else(|| other("no private key found"))?;
    let cfg = rustls::ServerConfig::builder_with_provider(Arc::new(
        rustls::crypto::ring::default_provider(),
    ))
    .with_safe_default_protocol_versions()
    .map_err(other)?
    .with_no_client_auth()
    .with_single_cert(certs, key)
    .map_err(other)?;
    Ok(Arc::new(cfg))
}

pub fn tls_client_config(ca: &Path) -> io::Result<Arc<rustls::ClientConfig>> {
    let mut roots = rustls::RootCertStore::empty();
    for c in load_certs(ca)? {
        roots.add(c).map_err(other)?;
    }
    let cfg = rustls::ClientConfig::builder_with_provider(Arc::new(
        rustls::crypto::ring::default_provider(),
    ))
    .with_safe_default_protocol_versions()
    .map_err(other)?
    .with_root_certificates(roots)
    .with_no_client_auth();
    Ok(Arc::new(cfg))
}

// ---------------------------------------------------------------- framing I/O
fn read_exact_vec(s: &mut dyn Stream, n: usize) -> io::Result<Vec<u8>> {
    let mut b = vec![0u8; n];
    s.read_exact(&mut b)?;
    Ok(b)
}

/// Read exactly n bytes, failing if the whole read takes longer than `deadline`
/// (a peer that trickles bytes cannot hold a connection slot indefinitely).
fn read_exact_deadline(s: &mut dyn Stream, n: usize, deadline: Instant) -> io::Result<Vec<u8>> {
    let mut b = vec![0u8; n];
    let mut got = 0;
    while got < n {
        if Instant::now() > deadline {
            return Err(io::Error::new(
                io::ErrorKind::TimedOut,
                "frame not received in time",
            ));
        }
        let end = (got + 64 * 1024).min(n);
        let k = s.read(&mut b[got..end])?;
        if k == 0 {
            return Err(io::Error::new(
                io::ErrorKind::UnexpectedEof,
                "connection closed",
            ));
        }
        got += k;
    }
    Ok(b)
}

fn write_frame(s: &mut dyn Stream, f: &[u8]) -> io::Result<()> {
    s.write_all(&(f.len() as u32).to_be_bytes())?;
    s.write_all(f)?;
    s.flush()
}

// --------------------------------------------------------------------- client
pub struct SendOptions {
    pub mode: Mode,
    pub chunk: usize, // bytes of data per frame when streaming
    pub retries: u32, // re-sends of a frame answered with "ER"
}

impl Default for SendOptions {
    fn default() -> Self {
        SendOptions {
            mode: Mode::Bcd,
            chunk: 1 << 20,
            retries: 3,
        }
    }
}

pub struct SendReport {
    pub data_bytes: u64,
    pub wire_bytes: u64,
    pub frames: u64,
    pub retries: u64,
}

pub fn connect(
    host: &str,
    port: u16,
    tls: Option<(Arc<rustls::ClientConfig>, String)>,
) -> io::Result<Box<dyn Stream>> {
    let tcp = TcpStream::connect((host, port))?;
    tcp.set_nodelay(true)?;
    tcp.set_read_timeout(Some(Duration::from_secs(60)))?;
    tcp.set_write_timeout(Some(Duration::from_secs(60)))?;
    match tls {
        None => Ok(Box::new(tcp)),
        Some((cfg, name)) => {
            let sn = rustls::pki_types::ServerName::try_from(name).map_err(other)?;
            let conn = rustls::ClientConnection::new(cfg, sn).map_err(other)?;
            Ok(Box::new(rustls::StreamOwned::new(conn, tcp)))
        }
    }
}

/// Send a whole file. Files not larger than one chunk are sent as a single frame (flags = 0,
/// compatible with the Python implementation); larger files are streamed chunk by chunk.
pub fn send_file(s: &mut dyn Stream, path: &Path, opt: &SendOptions) -> io::Result<SendReport> {
    let size = fs::metadata(path)?.len();
    let mut f = File::open(path)?;
    let chunk = opt.chunk.max(4) / 4 * 4;
    let mut rep = SendReport {
        data_bytes: 0,
        wire_bytes: 0,
        frames: 0,
        retries: 0,
    };
    let streaming = size > chunk as u64;
    let mut buf = vec![0u8; chunk];
    let mut sent: u64 = 0;
    loop {
        let n = read_full(&mut f, &mut buf)?;
        if n == 0 && sent < size {
            return Err(other("file shrank while it was being sent"));
        }
        let last = sent + n as u64 >= size;
        let flags = if streaming {
            FLAG_STREAM | if last { FLAG_LAST } else { 0 }
        } else {
            0
        };
        let fr = frame::make_frame(&buf[..n], opt.mode, flags);
        let mut attempt = 0;
        loop {
            if let Err(e) = write_frame(s, &fr) {
                // the receiver may have refused the connection with "BY" and closed it
                let mut ack = [0u8; 2];
                if s.read_exact(&mut ack).is_ok() && &ack == ACK_BUSY {
                    return Err(other("receiver busy (connection limit reached)"));
                }
                return Err(e);
            }
            rep.wire_bytes += 4 + fr.len() as u64;
            let mut ack = [0u8; 2];
            s.read_exact(&mut ack)?;
            if &ack == ACK_OK {
                break;
            }
            if &ack == ACK_BUSY {
                return Err(other("receiver busy (connection limit reached)"));
            }
            attempt += 1;
            rep.retries += 1;
            if attempt > opt.retries {
                return Err(other("frame rejected by receiver after retries"));
            }
        }
        rep.frames += 1;
        sent += n as u64;
        rep.data_bytes = sent;
        if last {
            break;
        }
    }
    Ok(rep)
}

fn read_full(f: &mut File, buf: &mut [u8]) -> io::Result<usize> {
    let mut n = 0;
    while n < buf.len() {
        let k = f.read(&mut buf[n..])?;
        if k == 0 {
            break;
        }
        n += k;
    }
    Ok(n)
}

// --------------------------------------------------------------------- server
pub struct ServerOptions {
    pub port: u16,
    pub out_dir: PathBuf,
    pub max_clients: usize,
    pub max_frame: usize,
    pub once: bool,
    pub tls: Option<Arc<rustls::ServerConfig>>,
}

static SEQ: AtomicUsize = AtomicUsize::new(0);

struct SlotGuard(Arc<AtomicUsize>);
impl Drop for SlotGuard {
    fn drop(&mut self) {
        self.0.fetch_sub(1, Ordering::SeqCst);
    }
}

fn unique_name(dir: &Path) -> PathBuf {
    let ms = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    dir.join(format!(
        "received_{ms}_{}.bin",
        SEQ.fetch_add(1, Ordering::Relaxed)
    ))
}

/// Handle one connection: a single frame, or a stream of frames ending with FLAG_LAST.
/// Data is written to a ".part" file and renamed only when complete and verified.
pub fn handle_connection(
    s: &mut dyn Stream,
    out_dir: &Path,
    max_frame: usize,
) -> io::Result<(PathBuf, u64)> {
    let final_path = unique_name(out_dir);
    let part = final_path.with_extension("bin.part");
    let mut out = File::create(&part)?;
    let mut total: u64 = 0;
    let result = (|| -> io::Result<()> {
        loop {
            let len = u32::from_be_bytes(read_exact_vec(s, 4)?.try_into().unwrap()) as usize;
            if len > max_frame {
                s.write_all(ACK_ERR)?;
                return Err(other(format!(
                    "frame of {len} bytes exceeds limit {max_frame}"
                )));
            }
            // allow 60 s plus 1 s per MiB for the body to arrive
            let deadline = Instant::now() + Duration::from_secs(60 + (len >> 20) as u64);
            let fr = read_exact_deadline(s, len, deadline)?;
            match frame::parse_frame(&fr) {
                Ok(p) => {
                    out.write_all(&p.data)?;
                    total += p.data.len() as u64;
                    s.write_all(ACK_OK)?;
                    s.flush()?;
                    let streaming = p.flags & FLAG_STREAM != 0;
                    if !streaming || p.flags & FLAG_LAST != 0 {
                        return Ok(());
                    }
                }
                Err(e) => {
                    // ask for retransmission of this frame; the sender bounds the number of retries
                    s.write_all(ACK_ERR)?;
                    s.flush()?;
                    eprintln!("  frame rejected: {e}");
                }
            }
        }
    })();
    drop(out);
    match result {
        Ok(()) => {
            fs::rename(&part, &final_path)?;
            Ok((final_path, total))
        }
        Err(e) => {
            let _ = fs::remove_file(&part);
            Err(e)
        }
    }
}

pub fn serve(opt: ServerOptions) -> io::Result<()> {
    fs::create_dir_all(&opt.out_dir)?;
    let listener = TcpListener::bind(("0.0.0.0", opt.port))?;
    let active = Arc::new(AtomicUsize::new(0));
    eprintln!(
        "listening on port {} ({}), up to {} clients, output in {}",
        opt.port,
        if opt.tls.is_some() {
            "TLS"
        } else {
            "plain TCP"
        },
        opt.max_clients,
        opt.out_dir.display()
    );
    for conn in listener.incoming() {
        let tcp = match conn {
            Ok(t) => t,
            Err(e) => {
                eprintln!("accept error: {e}");
                continue;
            }
        };
        let peer = tcp.peer_addr().map(|a| a.to_string()).unwrap_or_default();
        let _ = tcp.set_read_timeout(Some(Duration::from_secs(30)));
        let _ = tcp.set_write_timeout(Some(Duration::from_secs(30)));
        let max = opt.max_clients;
        if active
            .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |a| {
                if a < max {
                    Some(a + 1)
                } else {
                    None
                }
            })
            .is_err()
        {
            let mut t = tcp;
            let _ = t.write_all(ACK_BUSY);
            eprintln!("[{peer}] refused: connection limit reached");
            continue;
        }
        let (active2, dir, maxf, tls) = (
            active.clone(),
            opt.out_dir.clone(),
            opt.max_frame,
            opt.tls.clone(),
        );
        let worker = std::thread::spawn(move || {
            let _slot = SlotGuard(active2); // released even if this thread panics
            let res = (|| -> io::Result<(PathBuf, u64)> {
                let mut stream: Box<dyn Stream> = match tls {
                    None => Box::new(tcp),
                    Some(cfg) => {
                        let conn = rustls::ServerConnection::new(cfg).map_err(other)?;
                        Box::new(rustls::StreamOwned::new(conn, tcp))
                    }
                };
                handle_connection(stream.as_mut(), &dir, maxf)
            })();
            match res {
                Ok((p, n)) => eprintln!(
                    "[{peer}] {n} bytes received and verified -> {}",
                    p.display()
                ),
                Err(e) if e.kind() == io::ErrorKind::UnexpectedEof => eprintln!(
                    "[{peer}] connection closed before a complete frame (partial data discarded)"
                ),
                Err(e) => eprintln!("[{peer}] connection failed: {e}"),
            }
        });
        if opt.once {
            let _ = worker.join();
            return Ok(());
        }
    }
    Ok(())
}
