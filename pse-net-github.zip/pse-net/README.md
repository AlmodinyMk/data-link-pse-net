# pse-net

[![CI](https://github.com/OWNER/pse-net/actions/workflows/ci.yml/badge.svg)](https://github.com/OWNER/pse-net/actions/workflows/ci.yml)

**Weighted Pair-Symbol Encoding (PSE)** — codec, framing and network transport in Rust,
with a wire-compatible Python reference implementation.

Each byte is split into two 4-bit groups and four 2-bit pairs (weights `00:2 01:3 10:5 11:13`)
and represented as a decimal value `X.0YY` (X = relational state, YY = sum, ladder rule for
repeats). Four bytes form a number such as `3468.025033036018`; on the wire the fixed zeros
are dropped and 12 BCD digits (48 bits) carry the 4 bytes.

> This is a research representation, not a compressor: `bcd` mode sends 1.5x the data and
> `raw` mode sends the data itself (1.0x). See `docs/` for the papers.

## Build and test
```
cargo build --release
cargo test --release              # unit tests + loopback network tests (all OSes)
./scripts/integration_test.sh     # TLS, 20 MB streaming, concurrency (Linux/macOS, needs openssl)
./scripts/interop_test.sh         # Rust <-> Python wire compatibility
```
Minimum Rust version: 1.75. On Windows the `ring` crate needs the MSVC build tools.

## Use
```
pse_net receive --port 5050 --out-dir recv [--max-clients 16] [--max-frame-mb 64] [--once]
                [--tls-cert server.pem --tls-key server.key]
pse_net send --host 192.168.1.10 --port 5050 file.bin [--mode bcd|raw] [--chunk-kb 1024]
             [--tls-ca ca.pem --server-name host.example]
pse_net encode file.bin
pse_net decode 3468.025033036018
```

## Design
* Reliability, ordering, retransmission of lost segments, congestion control and MTU
  segmentation are provided by TCP and are not re-implemented.
* Application layer: length-prefixed frames, CRC-32, per-frame ACK (`OK` / `ER` / `BY`),
  bounded re-send of a frame that fails verification, chunked streaming in constant memory,
  `.part` files renamed only after the last frame is verified.
* Server: one thread per connection, connection limit, per-frame deadline, size limits,
  length fields validated before any allocation.
* Security: TLS 1.2/1.3 via rustls with server authentication. Without TLS the transport is
  neither encrypted nor authenticated.

## Frame (big-endian)
```
"PSE2" | mode(1) | flags(1) | original length(4) | body length(4) | CRC-32(4) | body
mode : 1 = bcd (6 bytes per 4 data bytes), 2 = raw
flags: bit1 STREAM (more frames follow), bit2 LAST; bit0 (encrypted) is refused
```

## Known limitations
No resume after an interrupted transfer, no client authentication (mTLS), thread-per-connection
(not intended for thousands of clients), custom protocol with no external tooling.

## Layout
```
src/        codec.rs  frame.rs  net.rs  lib.rs  main.rs
tests/      loopback.rs              network tests (all platforms)
scripts/    integration_test.sh  interop_test.sh
python/     pse_net_plain.py         Python reference implementation (standard library only)
docs/       papers (PDF)
.github/workflows/ci.yml             CI: Linux, Windows, macOS, MSRV 1.75, lint, integration
```

## License
MIT — see LICENSE.
