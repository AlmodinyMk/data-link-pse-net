#!/usr/bin/env bash
# End-to-end tests with the release binary: TCP, 20 MB streaming, TLS (test CA), wrong CA,
# 8 concurrent clients. Runs on Linux and macOS (needs openssl).
set -u
B=${B:-./target/release/pse_net}
T=$(mktemp -d)
PIDS=()
cleanup() { for p in "${PIDS[@]:-}"; do kill "$p" 2>/dev/null; done; rm -rf "$T"; }
trap cleanup EXIT
FAILED=0
pass() { echo "PASS  $1"; }
fail() { echo "FAIL  $1"; FAILED=1; }
start() { "$B" receive "$@" > /dev/null 2>&1 & PIDS+=($!); sleep 1; }

head -c 5000 /dev/urandom > "$T/small.bin"
head -c 20000000 /dev/urandom > "$T/big.bin"

start --port 7001 --out-dir "$T/r1"
"$B" send --port 7001 "$T/small.bin" > /dev/null && "$B" send --port 7001 "$T/big.bin" > /dev/null
sleep 1; n=0
for f in "$T"/r1/*.bin; do { cmp -s "$f" "$T/small.bin" || cmp -s "$f" "$T/big.bin"; } && n=$((n+1)); done
[ "$n" = 2 ] && pass "plain TCP: single frame + 20 MB stream" || fail "plain TCP ($n/2)"

openssl req -x509 -newkey rsa:2048 -nodes -keyout "$T/ca.key" -out "$T/ca.pem" -days 1 -subj "/CN=Test CA" 2>/dev/null
openssl req -newkey rsa:2048 -nodes -keyout "$T/srv.key" -out "$T/srv.csr" -subj "/CN=localhost" 2>/dev/null
printf "subjectAltName=DNS:localhost\nextendedKeyUsage=serverAuth\n" > "$T/ext.cnf"
openssl x509 -req -in "$T/srv.csr" -CA "$T/ca.pem" -CAkey "$T/ca.key" -CAcreateserial -out "$T/srv.pem" -days 1 -extfile "$T/ext.cnf" 2>/dev/null
openssl req -x509 -newkey rsa:2048 -nodes -keyout "$T/o.key" -out "$T/o.pem" -days 1 -subj "/CN=Other" 2>/dev/null
start --port 7002 --out-dir "$T/r2" --tls-cert "$T/srv.pem" --tls-key "$T/srv.key"
if "$B" send --port 7002 "$T/big.bin" --tls-ca "$T/ca.pem" --server-name localhost > /dev/null; then
  sleep 1; cmp -s "$T"/r2/*.bin "$T/big.bin" && pass "TLS: 20 MB" || fail "TLS content"
else fail "TLS send"; fi
"$B" send --port 7002 "$T/small.bin" --tls-ca "$T/o.pem" --server-name localhost 2> /dev/null \
  && fail "wrong CA accepted" || pass "TLS: wrong CA rejected"

start --port 7003 --out-dir "$T/r3"
CP=()
for i in 1 2 3 4 5 6 7 8; do "$B" send --port 7003 "$T/small.bin" --chunk-kb 1 > /dev/null & CP+=($!); done
for p in "${CP[@]}"; do wait "$p"; done
sleep 1; n=0
for f in "$T"/r3/*.bin; do cmp -s "$f" "$T/small.bin" && n=$((n+1)); done
[ "$n" = 8 ] && pass "8 concurrent clients" || fail "concurrency ($n/8)"

echo; [ "$FAILED" = 0 ] && echo "ALL PASSED" || { echo "SOME TESTS FAILED"; exit 1; }
