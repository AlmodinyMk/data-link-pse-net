#!/usr/bin/env bash
# Wire compatibility between the Rust binary and python/pse_net_plain.py (both directions).
set -u
B=${B:-./target/release/pse_net}
PY=${PY:-python3}
T=$(mktemp -d)
PIDS=()
cleanup() { for p in "${PIDS[@]:-}"; do kill "$p" 2>/dev/null; done; rm -rf "$T"; }
trap cleanup EXIT
FAILED=0
head -c 5000 /dev/urandom > "$T/a.bin"; head -c 300000 /dev/urandom > "$T/b.bin"

"$B" receive --port 7101 --out-dir "$T/r" > /dev/null 2>&1 & PIDS+=($!); sleep 1
for m in bcd raw; do for f in a b; do "$PY" python/pse_net_plain.py send --port 7101 --mode $m "$T/$f.bin" > /dev/null || FAILED=1; done; done
sleep 1; n=0
for f in "$T"/r/*.bin; do { cmp -s "$f" "$T/a.bin" || cmp -s "$f" "$T/b.bin"; } && n=$((n+1)); done
[ "$n" = 4 ] && echo "PASS  python -> rust (4/4)" || { echo "FAIL  python -> rust ($n/4)"; FAILED=1; }

"$PY" python/pse_net_plain.py receive --port 7102 --out "$T/py.bin" --once > /dev/null 2>&1 & PIDS+=($!); sleep 1
"$B" send --port 7102 "$T/b.bin" --chunk-kb 4096 > /dev/null
sleep 1
cmp -s "$T/py.bin" "$T/b.bin" && echo "PASS  rust -> python" || { echo "FAIL  rust -> python"; FAILED=1; }

"$PY" python/pse_net_plain.py selftest > /dev/null && echo "PASS  python selftest" || { echo "FAIL  python selftest"; FAILED=1; }
exit $FAILED
