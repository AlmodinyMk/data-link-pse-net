//! Cross-platform network tests (Linux, macOS, Windows): plain TCP on 127.0.0.1.
use pse_net::frame::Mode;
use pse_net::net::{self, SendOptions, ServerOptions};
use std::io::{Read, Write};
use std::net::TcpStream;
use std::path::{Path, PathBuf};
use std::thread;
use std::time::Duration;

fn temp_dir(name: &str) -> PathBuf {
    let d = std::env::temp_dir().join(format!("pse_net_test_{name}_{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&d);
    std::fs::create_dir_all(&d).unwrap();
    d
}

fn pseudo_random(n: usize, seed: u64) -> Vec<u8> {
    let mut x = seed;
    (0..n)
        .map(|_| {
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            (x >> 24) as u8
        })
        .collect()
}

fn start_server(port: u16, out: &Path, max_clients: usize) {
    let opt = ServerOptions {
        port,
        out_dir: out.to_path_buf(),
        max_clients,
        max_frame: 64 << 20,
        once: false,
        tls: None,
    };
    thread::spawn(move || net::serve(opt).unwrap());
    for _ in 0..50 {
        if TcpStream::connect(("127.0.0.1", port)).is_ok() {
            thread::sleep(Duration::from_millis(50));
            return;
        }
        thread::sleep(Duration::from_millis(50));
    }
    panic!("server did not start");
}

fn send(port: u16, file: &Path, mode: Mode, chunk: usize) {
    let mut s = net::connect("127.0.0.1", port, None).unwrap();
    net::send_file(
        s.as_mut(),
        file,
        &SendOptions {
            mode,
            chunk,
            retries: 3,
        },
    )
    .unwrap();
}

fn received(out: &Path) -> Vec<Vec<u8>> {
    thread::sleep(Duration::from_millis(300));
    let mut v: Vec<Vec<u8>> = std::fs::read_dir(out)
        .unwrap()
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().map(|x| x == "bin").unwrap_or(false))
        .map(|p| std::fs::read(p).unwrap())
        .collect();
    v.sort_by_key(|d| d.len());
    v
}

#[test]
fn single_frame_and_stream_both_modes() {
    let dir = temp_dir("stream");
    let out = dir.join("out");
    start_server(47101, &out, 8);
    let small = pseudo_random(5_000, 1);
    let big = pseudo_random(3_000_000, 2);
    std::fs::write(dir.join("small.bin"), &small).unwrap();
    std::fs::write(dir.join("big.bin"), &big).unwrap();
    send(47101, &dir.join("small.bin"), Mode::Bcd, 1 << 20);
    send(47101, &dir.join("big.bin"), Mode::Bcd, 64 << 10); // 46 frames
    send(47101, &dir.join("big.bin"), Mode::Raw, 64 << 10);
    let r = received(&out);
    assert_eq!(r.len(), 3);
    assert_eq!(r[0], small);
    assert_eq!(r[1], big);
    assert_eq!(r[2], big);
}

#[test]
fn concurrent_clients() {
    let dir = temp_dir("concurrent");
    let out = dir.join("out");
    start_server(47102, &out, 16);
    let data = pseudo_random(500_000, 3);
    std::fs::write(dir.join("d.bin"), &data).unwrap();
    let file = dir.join("d.bin");
    let hs: Vec<_> = (0..8)
        .map(|_| {
            let f = file.clone();
            thread::spawn(move || send(47102, &f, Mode::Bcd, 32 << 10))
        })
        .collect();
    for h in hs {
        h.join().unwrap();
    }
    let r = received(&out);
    assert_eq!(r.len(), 8);
    assert!(r.iter().all(|x| *x == data));
}

#[test]
fn hostile_frames_do_not_stop_the_server() {
    let dir = temp_dir("hostile");
    let out = dir.join("out");
    start_server(47103, &out, 8);
    // 1) declared original length of 4 GiB with a 6-byte body
    let mut hdr = b"PSE2".to_vec();
    hdr.extend_from_slice(&[1, 0]);
    hdr.extend_from_slice(&u32::MAX.to_be_bytes());
    hdr.extend_from_slice(&6u32.to_be_bytes());
    hdr.extend_from_slice(&0u32.to_be_bytes());
    hdr.extend_from_slice(&[0u8; 6]);
    let mut s = TcpStream::connect(("127.0.0.1", 47103)).unwrap();
    s.write_all(&(hdr.len() as u32).to_be_bytes()).unwrap();
    s.write_all(&hdr).unwrap();
    let mut ack = [0u8; 2];
    s.read_exact(&mut ack).unwrap();
    assert_eq!(&ack, b"ER");
    drop(s);
    // 2) oversized length prefix
    let mut s = TcpStream::connect(("127.0.0.1", 47103)).unwrap();
    s.write_all(&(1u32 << 30).to_be_bytes()).unwrap();
    s.read_exact(&mut ack).unwrap();
    assert_eq!(&ack, b"ER");
    drop(s);
    // 3) the server still accepts a valid transfer
    let data = pseudo_random(10_000, 4);
    std::fs::write(dir.join("ok.bin"), &data).unwrap();
    send(47103, &dir.join("ok.bin"), Mode::Bcd, 1 << 20);
    assert_eq!(received(&out), vec![data]);
}

#[test]
fn connection_limit_reports_busy() {
    let dir = temp_dir("busy");
    let out = dir.join("out");
    start_server(47104, &out, 1);
    let _hold = TcpStream::connect(("127.0.0.1", 47104)).unwrap(); // occupies the only slot
    thread::sleep(Duration::from_millis(200));
    std::fs::write(dir.join("x.bin"), [1u8, 2, 3, 4]).unwrap();
    let mut s = net::connect("127.0.0.1", 47104, None).unwrap();
    let e = net::send_file(s.as_mut(), &dir.join("x.bin"), &SendOptions::default())
        .err()
        .expect("should be refused");
    assert!(e.to_string().contains("busy"), "unexpected error: {e}");
}
